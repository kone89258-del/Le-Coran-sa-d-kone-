package com.saeedkone.quran

import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DeepGreen = Color(0xFF103E30)
private val Green = Color(0xFF185744)
private val Gold = Color(0xFFE7C77B)
private val Cream = Color(0xFFF7F5EE)

private data class Surah(val number: Int, val name: String)

private val surahs = listOf(
    "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام",
    "الأعراف", "الأنفال", "التوبة", "يونس", "هود", "يوسف", "الرعد",
    "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
    "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء",
    "النمل", "القصص", "العنكبوت", "الروم", "لقمان", "السجدة", "الأحزاب",
    "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر", "فصلت",
    "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح",
    "الحجرات", "ق", "الذاريات", "الطور", "النجم", "القمر", "الرحمن",
    "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة", "الصف",
    "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك",
    "القلم", "الحاقة", "المعارج", "نوح", "الجن", "المزمل", "المدثر",
    "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
    "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق",
    "الأعلى", "الغاشية", "الفجر", "البلد", "الشمس", "الليل", "الضحى",
    "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
    "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون",
    "الكوثر", "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس"
).mapIndexed { index, name -> Surah(index + 1, name) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranApp() }
    }
}

@Composable
private fun QuranApp() {
    val context = LocalContext.current
    var selectedSurah by remember { mutableStateOf<Surah?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var message by remember { mutableStateOf("أضف تسجيلات السور لبدء الاستماع") }

    DisposableEffect(Unit) {
        onDispose {
            player?.release()
            player = null
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            secondary = Gold,
            background = Cream,
            surface = Color.White
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Cream)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepGreen)
                    .padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("۞", color = Gold, fontSize = 34.sp)
                Text(
                    "القرآن الكريم",
                    color = Color.White,
                    fontSize = 27.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "بصوت سعيد كوني",
                    color = Gold,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(5.dp))
                Text("جمهورية مالي", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                colors = CardDefaults.cardColors(containerColor = Green),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        selectedSurah?.let { "السورة المختارة: ${it.name}" } ?: "مرحبًا بك في مكتبة التلاوات",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(message, color = Gold, fontSize = 13.sp)
                    if (selectedSurah != null) {
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = {
                                    val s = selectedSurah ?: return@Button
                                    val fileName = "surah_%03d".format(s.number)
                                    val resId = context.resources.getIdentifier(
                                        fileName, "raw", context.packageName
                                    )
                                    if (resId == 0) {
                                        message = "التسجيل غير مضاف بعد: $fileName.mp3"
                                        isPlaying = false
                                    } else {
                                        try {
                                            player?.release()
                                            player = MediaPlayer.create(context, resId)
                                            player?.setOnCompletionListener {
                                                isPlaying = false
                                                message = "انتهت التلاوة"
                                            }
                                            player?.start()
                                            isPlaying = true
                                            message = "جارٍ تشغيل سورة ${s.name}"
                                        } catch (e: Exception) {
                                            message = "تعذر تشغيل التسجيل. تحقق من الملف الصوتي."
                                            isPlaying = false
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Gold,
                                    contentColor = DeepGreen
                                )
                            ) {
                                Text(if (isPlaying) "تشغيل من جديد" else "تشغيل التلاوة")
                            }
                            Spacer(Modifier.width(10.dp))
                            OutlinedButton(
                                onClick = {
                                    player?.pause()
                                    isPlaying = false
                                    message = "تم إيقاف التلاوة مؤقتًا"
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                            ) { Text("إيقاف مؤقت") }
                        }
                    }
                }
            }

            Text(
                "اختر السورة",
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp),
                color = DeepGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
                textAlign = TextAlign.Start
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(surahs) { _, surah ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedSurah = surah
                                message = "السورة ${surah.number} — أضف ملفها الصوتي لتشغيلها"
                                isPlaying = false
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedSurah?.number == surah.number)
                                Color(0xFFECE2C8) else Color.White
                        ),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "%03d".format(surah.number),
                                color = Green,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(14.dp))
                            Text(
                                surah.name,
                                modifier = Modifier.weight(1f),
                                color = DeepGreen,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text("استماع  ◀", color = Green, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
